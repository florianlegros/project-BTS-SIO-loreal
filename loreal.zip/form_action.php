<?php
session_start();
$DATABASE
AME = 'loreal';
 
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}
if ( !isset($_POST['q1'], $_POST['q2'], $_POST['q3'], $_POST['q4'], $_POST['q5'], $_POST['q6'], $_POST['q7'], $_POST['q8'], $_POST['q9'], $_POST['q10']) ) {
	exit('Please fill all fields!');
}else{

    $query = 'SELECT idformulaire FROM formulaire WHERE users_id = ' . $_SESSION['id'];
    mysqli_query($con,$query);
    $check = mysqli_field_count($con);
    echo $check;

    if($check > 0){
        if ($stmt = $con->prepare('UPDATE formulaire SET q1=?, q2=?, q3=?, q4=?, q5=?, q6=?, q7=?, q8=?, q9=?, q10=? WHERE users_id = ?')) 
        { 
            $stmt->bind_param('ssssssssssi', $_POST['q1'], $_POST['q2'], $_POST['q3'], $_POST['q4'], $_POST['q5'], $_POST['q6'], $_POST['q7'], $_POST['q8'], $_POST['q9'], $_POST['q10'], $_SESSION['id']);
            $stmt->execute();
            
            header("location: profile.php");
        }
    }else{
        if ($stmt = $con->prepare('INSERT INTO formulaire (users_id, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')) 
        {
            $stmt->bind_param('issssssssss', $_SESSION['id'], $_POST['q1'], $_POST['q2'], $_POST['q3'], $_POST['q4'], $_POST['q5'], $_POST['q6'], $_POST['q7'], $_POST['q8'], $_POST['q9'], $_POST['q10']);
            $stmt->execute();
            
            header("location: profile.php");
        }
    }
        $stmt->close();
        $con->close();

}


?>
