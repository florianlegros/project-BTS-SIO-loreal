<?php 

$DATABASE_HOST = 'localhost:3306';
$DATABASE_USER = 'loreal';
$DATABASE_PASS = 'w{X?x2K30t)p)ql(';
$DATABASE_NAME = 'loreal';

