<?php

class Bdd{
    public $con;

    function __construct(){
        require 'config.php';
        $this->con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
        if ($this->con->connect_error) {
            exit('Failed to connect to MySQL: ');
        }
    }


}